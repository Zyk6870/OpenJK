#!/bin/bash

./openjkded.x86_64 +set fs_game zykmod +exec server.cfg

