START "Test Zyk Mod" /ABOVENORMAL openjkded.x86.exe +set fs_game zykmod +set dedicated 2 +set net_port 29070 +exec server.cfg
