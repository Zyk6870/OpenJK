
/////////////////////////////////////////////////////////
STAR WARS JEDI KNIGHT MODIFICATION
/////////////////////////////////////////////////////////

-----------
New Zyk Mod
-----------

Welcome to New Zyk Mod.

-------------
About The Mod
-------------

This is a RPG mod, quests, admin commands, an entity (building) system, and more.
This is similar to the Zyk OpenJK Mod, but with a different skill system and a whole
new main quest.

If you want to see the commands and features of the mod, look at the Documentation files.

Release Date: Oct 14, 2024

------------
Installation
------------

For installation instructions, read the Documentation files, at Installation section.

------------------------
Contributions to the Mod
------------------------

You can contribute and/or fork the mod. :D
It uses the openworld_rpg_mod branch.

You can clone the project with this command:

git clone https://github.com/Zyk6870/OpenJK.git

-------
License
-------

GNU General Public License version 2 (GPLv2)

-----------
Suggestions
-----------

Feel free to give suggestions and/or improvements to the mod. :D


/////////////////////////////////////////////////////////
THIS FILE OR THIS LEVEL IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY LUCASARTS, A DIVISION OF LUCASFILM ENTERTAINMENT COMPANY LTD. ELEMENTS � & (�) LUCASARTS, A DIVISION OF LUCASFILM ENTERTAINMENT COMPANY LTD.
/////////////////////////////////////////////////////////
